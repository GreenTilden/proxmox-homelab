import{h as k,d as E,r as y,o as H,a as P,c as x,b as m,e,t as h,w as A,v as V,F as I,f as O,n as b,g as B,i as N,j,k as F,l as U,u as $,m as q}from"./vendor-B8qu0SGd.js";(function(){const s=document.createElement("link").relList;if(s&&s.supports&&s.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))i(n);new MutationObserver(n=>{for(const a of n)if(a.type==="childList")for(const d of a.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&i(d)}).observe(document,{childList:!0,subtree:!0});function c(n){const a={};return n.integrity&&(a.integrity=n.integrity),n.referrerPolicy&&(a.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?a.credentials="include":n.crossOrigin==="anonymous"?a.credentials="omit":a.credentials="same-origin",a}function i(n){if(n.ep)return;n.ep=!0;const a=c(n);fetch(n.href,a)}})();/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=l=>l.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),G=l=>l.replace(/^([A-Z])|[\s-_]+(\w)/g,(s,c,i)=>i?i.toUpperCase():c.toLowerCase()),z=l=>{const s=G(l);return s.charAt(0).toUpperCase()+s.slice(1)},K=(...l)=>l.filter((s,c,i)=>!!s&&s.trim()!==""&&i.indexOf(s)===c).join(" ").trim();/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var v={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Z=({size:l,strokeWidth:s=2,absoluteStrokeWidth:c,color:i,iconNode:n,name:a,class:d,...p},{slots:g})=>k("svg",{...v,width:l||v.width,height:l||v.height,stroke:i||v.stroke,"stroke-width":c?Number(s)*24/Number(l):s,class:K("lucide",...a?[`lucide-${C(z(a))}-icon`,`lucide-${C(a)}`]:["lucide-icon"]),...p},[...n.map(f=>k(...f)),...g.default?[g.default()]:[]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=(l,s)=>(c,{slots:i})=>k(Z,{...c,iconNode:s,name:l},i);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=u("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=u("external-link",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=u("folder-open",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=u("monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=u("play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=u("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),ee={class:"p-8 text-center border-b-2",style:{background:"var(--section-bg)","border-color":"var(--primary-color)"}},te={class:"header-content"},oe={class:"flex items-center justify-center gap-2 mb-4 text-sm opacity-80"},se={class:"font-semibold",style:{color:"var(--primary-color)"}},ae={class:"flex items-center justify-center gap-4"},ne={class:"p-8 max-w-6xl mx-auto"},re={class:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"},le={class:"flex items-start gap-4 mb-4"},ie={class:"flex-1"},ce={class:"text-lg font-semibold mb-1",style:{color:"var(--text-color)"}},de={class:"text-sm opacity-80",style:{color:"var(--text-color)"}},he={class:"text-right flex flex-col items-end gap-1"},ue={key:0,class:"text-xs opacity-70",style:{color:"var(--text-color)"}},me={class:"text-right"},pe=["onClick"],ge=E({__name:"App",setup(l){const s=y("classic"),c={classic:"theme-classic",paint:"theme-paint",italy:"theme-italy",gameboy:"theme-gameboy"},i=t=>{const o=c[t];o&&(document.body.className=document.body.className.replace(/theme-\w+/g,""),document.body.classList.add(o))},n=()=>c[s.value]||"theme-classic",a=y(null),d=y(new Date),p=y([{id:"proxmox",name:"Proxmox VE",description:"Virtualization Management",url:"https://192.168.0.99:8006",icon:X,status:"checking",healthEndpoint:"https://192.168.0.99:8006/api2/json/version"},{id:"plex",name:"Plex Media Server",description:"Media Streaming Platform",url:"http://192.168.0.99:32400",icon:Y,status:"checking",healthEndpoint:"http://192.168.0.99:32400/identity"},{id:"grafana",name:"Grafana Dashboard",description:"Metrics Visualization",url:"http://192.168.0.99:3000",icon:W,status:"checking",healthEndpoint:"http://192.168.0.99:3000/api/health"},{id:"deluge",name:"Deluge Torrent Client",description:"Download Management",url:"http://192.168.0.111:8112",icon:J,status:"checking",healthEndpoint:"http://192.168.0.111:8112/"},{id:"filebrowser",name:"File Browser",description:"File Management Interface",url:"http://192.168.0.99:8080",icon:R,status:"checking",healthEndpoint:"http://192.168.0.99:8080/health"}]),g=async t=>{if(!t.healthEndpoint)return;const o=Date.now();t.status="checking";try{const r=new AbortController,w=setTimeout(()=>r.abort(),5e3),ye=await fetch(t.healthEndpoint,{method:"GET",signal:r.signal,mode:"no-cors"});clearTimeout(w),t.responseTime=Date.now()-o,t.lastChecked=new Date,t.status="online"}catch(r){t.responseTime=Date.now()-o,t.lastChecked=new Date,t.status="offline",console.warn(`Health check failed for ${t.name}:`,r)}},f=async()=>{d.value=new Date;const t=p.value.map(o=>g(o));await Promise.allSettled(t)},_=()=>{f(),a.value=window.setInterval(f,3e4)},M=()=>{a.value&&(clearInterval(a.value),a.value=null)},T=t=>{window.open(t,"_blank")},S=t=>{switch(t){case"online":return"✅";case"offline":return"❌";case"checking":return"🔄";default:return"❓"}},D=t=>{switch(t){case"online":return"Online";case"offline":return"Offline";case"checking":return"Checking...";default:return"Unknown"}},L=t=>{switch(t){case"online":return"mario-tag-success";case"offline":return"mario-tag-danger";case"checking":return"mario-tag-warning";default:return"mario-tag"}};return H(()=>{i(s.value),_()}),P(()=>{M()}),(t,o)=>(m(),x("div",{id:"app",class:b(["min-h-screen",n()])},[e("header",ee,[e("div",te,[o[4]||(o[4]=e("h1",{class:"text-4xl mb-2",style:{color:"var(--text-color)"}},"🤖 LCiBot Dashboard",-1)),o[5]||(o[5]=e("p",{class:"text-xl mb-8 opacity-80",style:{color:"var(--text-color)"}},"Proxmox Services & System Monitoring",-1)),e("div",oe,[o[1]||(o[1]=e("span",{style:{color:"var(--text-color)"}},"Last Health Check:",-1)),e("span",se,h(d.value.toLocaleTimeString()),1)]),e("div",ae,[o[3]||(o[3]=e("span",{class:"font-semibold",style:{color:"var(--text-color)"}},"Theme:",-1)),A(e("select",{"onUpdate:modelValue":o[0]||(o[0]=r=>s.value=r),onChange:i,class:"mario-select"},[...o[2]||(o[2]=[e("option",{value:"classic"},"🤖 Classic Mario",-1),e("option",{value:"paint"},"🎨 Mario Paint",-1),e("option",{value:"italy"},"🇮🇹 Italy",-1),e("option",{value:"gameboy"},"🟢 Game Boy",-1)])],544),[[V,s.value]])])])]),e("main",ne,[e("div",re,[(m(!0),x(I,null,O(p.value,r=>(m(),x("div",{key:r.id,class:"mario-card"},[e("div",le,[(m(),B(N(r.icon),{class:"w-8 h-8 flex-shrink-0",style:{color:"var(--primary-color)"}})),e("div",ie,[e("h3",ce,h(r.name),1),e("p",de,h(r.description),1)]),e("div",he,[e("span",{class:b(L(r.status))},h(S(r.status))+" "+h(D(r.status)),3),r.responseTime?(m(),x("div",ue,h(r.responseTime)+"ms ",1)):j("",!0)])]),e("div",me,[e("button",{onClick:w=>T(r.url),class:"mario-button inline-flex items-center gap-2"},[F($(Q),{class:"w-4 h-4"}),o[6]||(o[6]=U(" Access ",-1))],8,pe)])]))),128))])])],2))}}),fe=q(ge);fe.mount("#app");
