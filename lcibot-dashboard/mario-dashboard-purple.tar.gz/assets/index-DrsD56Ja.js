import{h as k,d as P,r as y,o as E,a as H,c as x,b as h,e as n,t as p,w as V,v as A,f as I,F as N,g as O,n as b,i as B,j,k as F,l as U,m as $,u as q,p as G}from"./vendor-BaTrZtsf.js";(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))i(a);new MutationObserver(a=>{for(const s of a)if(s.type==="childList")for(const d of s.addedNodes)d.tagName==="LINK"&&d.rel==="modulepreload"&&i(d)}).observe(document,{childList:!0,subtree:!0});function c(a){const s={};return a.integrity&&(s.integrity=a.integrity),a.referrerPolicy&&(s.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?s.credentials="include":a.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function i(a){if(a.ep)return;a.ep=!0;const s=c(a);fetch(a.href,s)}})();/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=l=>l.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),z=l=>l.replace(/^([A-Z])|[\s-_]+(\w)/g,(o,c,i)=>i?i.toUpperCase():c.toLowerCase()),K=l=>{const o=z(l);return o.charAt(0).toUpperCase()+o.slice(1)},Z=(...l)=>l.filter((o,c,i)=>!!o&&o.trim()!==""&&i.indexOf(o)===c).join(" ").trim();/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var v={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const J=({size:l,strokeWidth:o=2,absoluteStrokeWidth:c,color:i,iconNode:a,name:s,class:d,...m},{slots:g})=>k("svg",{...v,width:l||v.width,height:l||v.height,stroke:i||v.stroke,"stroke-width":c?Number(o)*24/Number(l):o,class:Z("lucide",...s?[`lucide-${C(K(s))}-icon`,`lucide-${C(s)}`]:["lucide-icon"]),...m},[...a.map(f=>k(...f)),...g.default?[g.default()]:[]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=(l,o)=>(c,{slots:i})=>k(J,{...c,iconNode:o,name:l},i);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Q=u("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const R=u("external-link",[["path",{d:"M15 3h6v6",key:"1q9fwt"}],["path",{d:"M10 14 21 3",key:"gplh6r"}],["path",{d:"M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6",key:"a6xqqp"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const X=u("folder-open",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Y=u("monitor",[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2",key:"48i651"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21",key:"1svkeh"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21",key:"vw1qmm"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const W=u("play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]);/**
 * @license lucide-vue-next v0.525.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ee=u("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),te={class:"p-8 text-center border-b-2",style:{background:"var(--section-bg)","border-color":"var(--primary-color)"}},oe={class:"header-content"},se={class:"flex items-center justify-center gap-2 mb-4 text-sm opacity-80"},ne={class:"font-semibold",style:{color:"var(--primary-color)"}},ae={class:"flex items-center justify-center gap-4"},re={class:"p-8 max-w-6xl mx-auto"},le={class:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"},ie={class:"flex items-start gap-4 mb-4"},ce={class:"flex-1"},de={class:"text-lg font-semibold mb-1",style:{color:"var(--text-color)"}},pe={class:"text-sm opacity-80",style:{color:"var(--text-color)"}},ue={class:"text-right flex flex-col items-end gap-1"},he={key:0,class:"text-xs opacity-70",style:{color:"var(--text-color)"}},me={class:"text-right"},ge=["onClick"],fe=P({__name:"App",setup(l){const o=y("purple"),c={purple:"theme-purple",classic:"theme-classic",paint:"theme-paint",italy:"theme-italy",gameboy:"theme-gameboy"},i=e=>{const t=c[e];t&&(document.body.className=document.body.className.replace(/theme-\w+/g,""),document.body.classList.add(t))},a=()=>c[o.value]||"theme-purple",s=y(null),d=y(new Date),m=y([{id:"proxmox",name:"Proxmox VE",description:"Virtualization Management",url:"https://192.168.0.99:8006",icon:Y,status:"checking",healthEndpoint:"https://192.168.0.99:8006/api2/json/version"},{id:"plex",name:"Plex Media Server",description:"Media Streaming Platform",url:"http://192.168.0.99:32400",icon:W,status:"checking",healthEndpoint:"http://192.168.0.99:32400/identity"},{id:"grafana",name:"Grafana Dashboard",description:"Metrics Visualization",url:"http://192.168.0.99:3000",icon:ee,status:"checking",healthEndpoint:"http://192.168.0.99:3000/api/health"},{id:"deluge",name:"Deluge Torrent Client",description:"Download Management",url:"http://192.168.0.111:8112",icon:Q,status:"checking",healthEndpoint:"http://192.168.0.111:8112/"},{id:"filebrowser",name:"File Browser",description:"File Management Interface",url:"http://192.168.0.99:8080",icon:X,status:"checking",healthEndpoint:"http://192.168.0.99:8080/health"}]),g=async e=>{if(!e.healthEndpoint)return;const t=Date.now();e.status="checking";try{const r=new AbortController,w=setTimeout(()=>r.abort(),5e3),xe=await fetch(e.healthEndpoint,{method:"GET",signal:r.signal,mode:"no-cors"});clearTimeout(w),e.responseTime=Date.now()-t,e.lastChecked=new Date,e.status="online"}catch(r){e.responseTime=Date.now()-t,e.lastChecked=new Date,e.status="offline",console.warn(`Health check failed for ${e.name}:`,r)}},f=async()=>{d.value=new Date;const e=m.value.map(t=>g(t));await Promise.allSettled(e)},_=()=>{f(),s.value=window.setInterval(f,3e4)},M=()=>{s.value&&(clearInterval(s.value),s.value=null)},S=e=>{window.open(e,"_blank")},T=e=>{switch(e){case"online":return"✅";case"offline":return"❌";case"checking":return"🔄";default:return"❓"}},D=e=>{switch(e){case"online":return"Online";case"offline":return"Offline";case"checking":return"Checking...";default:return"Unknown"}},L=e=>{switch(e){case"online":return"mario-tag-success";case"offline":return"mario-tag-danger";case"checking":return"mario-tag-warning";default:return"mario-tag"}};return E(()=>{i(o.value),_()}),H(()=>{M()}),(e,t)=>(h(),x("div",{id:"app",class:b(["min-h-screen",a()])},[n("header",te,[n("div",oe,[t[4]||(t[4]=n("h1",{class:"text-4xl mb-2",style:{color:"var(--text-color)"}},"🤖 LCiBot Dashboard",-1)),t[5]||(t[5]=n("p",{class:"text-xl mb-8 opacity-80",style:{color:"var(--text-color)"}},"Proxmox Services & System Monitoring",-1)),n("div",se,[t[1]||(t[1]=n("span",{style:{color:"var(--text-color)"}},"Last Health Check:",-1)),n("span",ne,p(d.value.toLocaleTimeString()),1)]),n("div",ae,[t[3]||(t[3]=n("span",{class:"font-semibold",style:{color:"var(--text-color)"}},"Theme:",-1)),V(n("select",{"onUpdate:modelValue":t[0]||(t[0]=r=>o.value=r),onChange:i,class:"mario-select"},[...t[2]||(t[2]=[I('<option value="purple">💜 Purple Magic</option><option value="classic">🤖 Classic Mario</option><option value="paint">🎨 Mario Paint</option><option value="italy">🇮🇹 Italy</option><option value="gameboy">🟢 Game Boy</option>',5)])],544),[[A,o.value]])])])]),n("main",re,[n("div",le,[(h(!0),x(N,null,O(m.value,r=>(h(),x("div",{key:r.id,class:"mario-card"},[n("div",ie,[(h(),B(j(r.icon),{class:"w-8 h-8 flex-shrink-0",style:{color:"var(--primary-color)"}})),n("div",ce,[n("h3",de,p(r.name),1),n("p",pe,p(r.description),1)]),n("div",ue,[n("span",{class:b(L(r.status))},p(T(r.status))+" "+p(D(r.status)),3),r.responseTime?(h(),x("div",he,p(r.responseTime)+"ms ",1)):F("",!0)])]),n("div",me,[n("button",{onClick:w=>S(r.url),class:"mario-button inline-flex items-center gap-2"},[U(q(R),{class:"w-4 h-4"}),t[6]||(t[6]=$(" Access ",-1))],8,ge)])]))),128))])])],2))}}),ye=G(fe);ye.mount("#app");
